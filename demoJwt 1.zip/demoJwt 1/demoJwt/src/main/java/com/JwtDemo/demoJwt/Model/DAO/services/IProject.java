package com.JwtDemo.demoJwt.Model.DAO.services;

import java.util.List;

import com.JwtDemo.demoJwt.Model.Pojo.Project;


public interface IProject {
	String insertProject(Project P);

	List<Project> getallprojects();
	String update(Project P,int projectid);
	String Delete(int projectid);
}
