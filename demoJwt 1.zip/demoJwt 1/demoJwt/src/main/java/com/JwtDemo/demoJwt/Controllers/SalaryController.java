package com.JwtDemo.demoJwt.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JwtDemo.demoJwt.Model.BL.RSalaryBL;
import com.JwtDemo.demoJwt.Model.Pojo.RSalary;
import com.JwtDemo.demoJwt.Model.dto.Salarydto;


@RestController
@RequestMapping("/salary")
public class SalaryController {
	@Autowired
	RSalaryBL rSalaryBL;

	@PostMapping("/add")
	public String AddSalary(@RequestBody Salarydto R) {
		System.out.println(R);
		return rSalaryBL.addSalary(R);
	}
	@GetMapping("/addall")
	public List<RSalary> AddAll() {
		return rSalaryBL.getAllSalaries();
	}

}
