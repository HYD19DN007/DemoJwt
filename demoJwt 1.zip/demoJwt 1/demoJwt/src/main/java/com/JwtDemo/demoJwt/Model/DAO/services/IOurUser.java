package com.JwtDemo.demoJwt.Model.DAO.services;

import java.util.List;
import java.util.Optional;

import com.JwtDemo.demoJwt.Model.Pojo.OurUsers;


public interface IOurUser {
String SaveUser(OurUsers ourusers);
List<OurUsers> AllUsers();
Optional<OurUsers> GetUserByEmail(String email);
}
