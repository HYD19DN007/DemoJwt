package com.JwtDemo.demoJwt.Model.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.JwtDemo.demoJwt.Model.Pojo.EmpDeptComposite;
import com.JwtDemo.demoJwt.Model.Pojo.Emp_Dept;
import com.JwtDemo.demoJwt.Model.dto.EmpDeptdto;
@Repository
public interface EmpDeptRepository extends JpaRepository<Emp_Dept, EmpDeptComposite> {
@Query(""" 
		select new com.JwtDemo.demoJwt.Model.dto.EmpDeptdto(
		e.empdept.emp.empno,
		e.empdept.dept.deptno,
		e.empdept.startdate,
		e.enddate
		) 
		from Emp_Dept e """ 
		)
List<EmpDeptdto> getalldetails();
	
	
}
