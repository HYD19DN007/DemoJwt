package com.JwtDemo.demoJwt.Model.DAO.serviceimpl;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtService {

    private static final String SECRET =
            "ThisIsMySecureSecretKeyForJwtAuthentication12345";

    private Key getSignedKey() {

        return Keys.hmacShaKeyFor(
                SECRET.getBytes(StandardCharsets.UTF_8)
        );
    }

    public String generateToken(String email, String role) {

        Map<String, Object> claims = new HashMap<>();

        claims.put("usertype", role.toUpperCase());

        return createToken(claims, email);
    }

    private String createToken(Map<String, Object> claims,
                               String email) {

    	return Jwts.builder()
    	        .claims(claims)
    	        .subject(email)
    	        .issuedAt(new Date())
    	        .expiration(new Date(System.currentTimeMillis() + 1000 * 60 * 15))
    	        .signWith(getSignedKey())
    	        .compact();    }

    private Claims extractAllClaims(String token) {

        return Jwts.parser()
                .verifyWith((javax.crypto.SecretKey) getSignedKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public <T> T extractClaim(String token,
                              Function<Claims, T> resolver) {

        Claims claims = extractAllClaims(token);

        return resolver.apply(claims);
    }

    public String extractUserName(String token) {

        return extractClaim(token, Claims::getSubject);
    }

    public String extractRoleFromToken(String token) {

        Claims claims = extractAllClaims(token);

        return claims.get("usertype", String.class);
    }

    public Date extractExpiration(String token) {

        return extractClaim(token, Claims::getExpiration);
    }

    private boolean isTokenExpired(String token) {

        return extractExpiration(token).before(new Date());
    }

    public boolean validateToken(String token) {

        try {

            return !isTokenExpired(token);

        } catch (Exception e) {

            return false;
        }
    }
}

