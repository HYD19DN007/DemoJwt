//package com.JwtDemo.demoJwt.Model.config;
//
//import org.springframework.context.annotation.Bean;
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.AuthenticationProvider;
//import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
//import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//import  static org.springframework.security.config.Customizer.withDefaults;
//@Configuration
//@EnableMethodSecurity
//@EnableWebSecurity
//public class SecurityConfig1 {
//
//	@Bean
//	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//		http.csrf(AbstractHttpConfigurer::disable)
//				.authorizeHttpRequests(
//						auth -> auth.requestMatchers("/auth/register", "/auth/Validate", "/auth/Validatetoken")
//								.permitAll().anyRequest().authenticated())
//				//.formLogin(withDefaults()); 
//				.httpBasic(withDefaults());
//
//		return http.build();
//	}
//
//	
//	
//	@Bean 
//	 public PasswordEncoder passwordEncoder()
//	 { 
//		 return new  BCryptPasswordEncoder(); 
//	 }
//	
//	@Bean 
//	public UserDetailsService userDetailsService()
//	{
//		
//		return new OurUserDetailService();
//	}
//	
//	@Bean
//	public AuthenticationProvider authenticationProvider()
//	{
//		DaoAuthenticationProvider daoAuthenticationProvider=new DaoAuthenticationProvider(userDetailsService());
//		daoAuthenticationProvider.setPasswordEncoder(passwordEncoder());//Fetch password from LOgin Page
//		return daoAuthenticationProvider;
//	
//	}
//	
//	@Bean
//	public AuthenticationManager authenticationManager
//		(AuthenticationConfiguration config)throws Exception
//	{
//		System.out.println("Authentication manager");
//		return config.getAuthenticationManager();
//	}
//	
//}
