package com.JwtDemo.demoJwt.Model.Pojo;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tblproject")
public class Project {
	@Id
	private int projectid;
	@Column(length = 20)
	private String projectname;
	private LocalDate startdate;
	private Integer teamsize;
	@Column(length = 20)
	private String projecthead;
}
