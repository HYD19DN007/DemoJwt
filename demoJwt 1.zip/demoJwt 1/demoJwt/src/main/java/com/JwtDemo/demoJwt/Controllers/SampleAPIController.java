//package com.JwtDemo.demoJwt.Controllers;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.JwtDemo.demoJwt.Model.DAO.serviceimpl.*;
//import com.JwtDemo.demoJwt.Model.Pojo.OurUsers;
//
//@RestController
//@RequestMapping("/auth")
//public class SampleAPIController {
//
//	@Autowired
//	AuthService authService;
//	@GetMapping("/index")
//	public String Index()
//	{
//		return "Index Page";
//	}
//	@PostMapping("/register")
//	public ResponseEntity<Object> InsertUser(@RequestBody OurUsers user)
//	{ 
//		String S=authService.SaveUser(user);
//		System.out.println(S);
//		return ResponseEntity.ok(S);
//	}
//
//	@GetMapping("/user")
//	@PreAuthorize("hasAuthority('user')")
//	public List<OurUsers> getUser()
//	{
//		return authService.getUsers();
//		
//	}
//	@GetMapping("/admin/{email}")
//	@PreAuthorize("hasAuthority('admin')")
//	public Optional<OurUsers> getAdmin(@PathVariable("email") String email)
//	{
//		return authService.FetchUserByEmail(email);
//		
//	}
//	@GetMapping("/getdetails")
//	public String getLogginUserDetails()
//	{
//		Authentication authentication=SecurityContextHolder.getContext().getAuthentication();
//		System.out.println(authentication.getPrincipal() + "Pricipal");
//		System.out.println(authentication.getName() + "getname");
//		System.out.println(authentication.getCredentials()+"credentials");
//		System.out.println(authentication.getAuthorities()+ "Authorities" );
//		if(authentication!=null && authentication.getPrincipal() instanceof UserDetailsService)
//		{
//			
//			return authentication.getAuthorities().toArray()[0].toString();
//		}
//		else 
//			return null;
//		
//	}
//	
//}
