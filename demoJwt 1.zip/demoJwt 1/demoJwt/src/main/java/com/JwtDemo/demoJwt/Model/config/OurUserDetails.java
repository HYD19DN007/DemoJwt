package com.JwtDemo.demoJwt.Model.config;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.jspecify.annotations.Nullable;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.JwtDemo.demoJwt.Model.Pojo.OurUsers;

public class OurUserDetails implements UserDetails {

	private static final long serialVersionUID = 1L;
	private String email;
	private String password;
	private List<GrantedAuthority>role;
	
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		System.out.println("Role");
		return this.role;
	}

	@Override
	public @Nullable String getPassword() {
		// TODO Auto-generated method stub
		System.out.println("Password");
		return this.password;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		System.out.println("Username");
		return this.email;
	}

	public OurUserDetails(OurUsers ourusers) {
		super();
		System.out.println("OurUsers Constructor");
		this.email = ourusers.getEmail();
		this.password = ourusers.getPassword();
		this.role =Arrays.stream(ourusers.getRole().split(","))
				.map(role -> new SimpleGrantedAuthority(role.toUpperCase()))
				.collect(Collectors.toList());
				
	
				//Manager,Associate,Admin
				//.new SimplGrantAuthority("manager")

	}

}
