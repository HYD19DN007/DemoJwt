package com.JwtDemo.demoJwt.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.GetExchange;

import com.JwtDemo.demoJwt.Model.BL.EmpDeptBL;
import com.JwtDemo.demoJwt.Model.Pojo.Emp_Dept;

@RestController
@RequestMapping("/ED")
public class EmpDeptController {
	@Autowired
	EmpDeptBL empDeptBL;

	@GetMapping("getall")
	public List<Emp_Dept> getall() {
		return empDeptBL.getall();
	}
}
