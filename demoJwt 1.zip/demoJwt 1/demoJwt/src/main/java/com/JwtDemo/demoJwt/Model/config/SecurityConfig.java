package com.JwtDemo.demoJwt.Model.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.JwtDemo.demoJwt.Model.DAO.serviceimpl.JwtService;
import com.JwtDemo.demoJwt.Model.filter.JwtAuthenticationFilter;

import jakarta.servlet.http.HttpServletResponse;

import static  org.springframework.security.config.Customizer.withDefaults;
import org.springframework.beans.factory.annotation.Autowired;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
	private final JwtService jwtService;

	public SecurityConfig(JwtService jwtService) {
		super();
		this.jwtService = jwtService;
	}
	@Bean
    public JwtAuthenticationFilter jwtAuthenticationFilter() {
        return new JwtAuthenticationFilter(userDetailsService(), jwtService);
    }

	@Bean 
	 public PasswordEncoder passwordEncoder()
	 { 
		 return new  BCryptPasswordEncoder(); 
	 }
	 //AuthorizationBlock

	 @Bean
	    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
	      http.authorizeHttpRequests
	        (auth->auth.requestMatchers("/auth/save","/auth/Validate","/auth/Validatetoken","/ED/**").permitAll()
	        		    		
	        		.requestMatchers("/Address/**").hasAuthority("USER")
	        		.requestMatchers("/Project/**").hasAuthority("ADMIN")
	        		// .requestMatchers("/auth/getusers")
	               //  .hasAuthority("ADMIN")
	        		.anyRequest().authenticated())
	                .sessionManagement(session -> session
	                .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
	                .authenticationProvider(authenticationProvider())
	                .addFilterBefore(jwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
	                .csrf(AbstractHttpConfigurer::disable)
	      			.logout(logout -> logout
	                .logoutUrl("/auth/Logout")
	                .logoutSuccessHandler((request, response, authentication) -> {
	                    response.setStatus(HttpServletResponse.SC_OK);
	                }));
	            
		 	        return http.build();
	            	        
	    }
	 @Bean
	 public UserDetailsService userDetailsService()
	 {
		 System.out.println("UserDetails Service");
		 return new OurUserDetailService();
		 //xyz  abc admin
		 //xyz   aaaaa
		 
	 }
	 
	 
		@Bean
		public AuthenticationProvider authenticationProvider()
		{
			DaoAuthenticationProvider daoAuthenticationProvider=new DaoAuthenticationProvider(userDetailsService());
			daoAuthenticationProvider.setPasswordEncoder(passwordEncoder());//Fetch password from LOgin Page
			return daoAuthenticationProvider;
	
		}
 
	 @Bean
	 public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception
	 {
		 System.out.println("Authentication Manager");
		 
		 return config.getAuthenticationManager();
	 }
	 
	 
	 
			  
}
