package com.JwtDemo.demoJwt.Model.DAO.services;

import java.util.List;

import com.JwtDemo.demoJwt.Model.Pojo.RSalary;
import com.JwtDemo.demoJwt.Model.dto.Salarydto;


public interface IRSalary {
String addSalary(Salarydto S);
List<RSalary>getAllSalaries();
}

