package com.JwtDemo.demoJwt.Model.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Data
public class EmpDeptdto {
private int empno;
private int deptno;
private LocalDate startdate;
private LocalDate enddate;
}
