package com.JwtDemo.demoJwt.Model.DAO.serviceimpl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.JwtDemo.demoJwt.Model.DAO.services.IREmployee;
import com.JwtDemo.demoJwt.Model.Pojo.RAddress;
import com.JwtDemo.demoJwt.Model.Pojo.REmployee;
import com.JwtDemo.demoJwt.Model.dto.Employeedto;
import com.JwtDemo.demoJwt.Model.repositories.RAddressRepository;
import com.JwtDemo.demoJwt.Model.repositories.REmployeeRepository;


@Service
public class REmployeeServiceImpl implements IREmployee {
	@Autowired
	RAddressRepository rAddressRepository;
	@Autowired
	REmployeeRepository rEmployeeRepository;

	@Override
	public String AddEmployee(Employeedto E) {
		Optional<RAddress> address =rAddressRepository.findById(E.getAddid());//100
		if(address.isPresent()) 
		{
			Optional<REmployee>oldemp=rEmployeeRepository.findById(E.getEmpno());
			if(oldemp.isEmpty())
					{
					REmployee emp=new REmployee();
					emp.setEmpno(E.getEmpno());
					emp.setEname(E.getEname());
					emp.setGender(E.getGender());
					emp.setAddress(address.get());
							
					rEmployeeRepository.save(emp);
					return "Employee Saved";
		
					}
					else
					{
						return "Employee Exists";
					}
		}
		else
			return "Address not found";
		}

	@Override
	public String UpdateEmployee(REmployee newemp, int empno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(int empno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<REmployee> getall() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<REmployee> getById(int empno) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

}
