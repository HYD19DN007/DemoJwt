package com.JwtDemo.demoJwt.Model.Pojo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class REmp {
	@Id
	private int empno;
	@Column(length = 15)
	private String ename;
}
