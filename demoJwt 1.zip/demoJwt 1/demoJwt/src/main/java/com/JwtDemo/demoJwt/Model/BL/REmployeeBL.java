package com.JwtDemo.demoJwt.Model.BL;
import org.springframework.beans.factory.annotation.Autowired;

import com.JwtDemo.demoJwt.Model.DAO.serviceimpl.REmployeeServiceImpl;
import com.JwtDemo.demoJwt.Model.dto.Employeedto;


public class REmployeeBL {
	@Autowired
	REmployeeServiceImpl rEmployeeServiceImpl;

	public String addEmployee(Employeedto E) {
		return rEmployeeServiceImpl.AddEmployee(E);
	}
}
