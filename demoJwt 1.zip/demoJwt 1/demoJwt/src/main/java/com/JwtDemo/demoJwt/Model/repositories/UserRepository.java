package com.JwtDemo.demoJwt.Model.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.JwtDemo.demoJwt.Model.Pojo.OurUsers;
@Repository
public interface UserRepository extends JpaRepository<OurUsers, Integer>{
	Optional<OurUsers> findByEmail(String username);
}
