package com.JwtDemo.demoJwt.Model.Pojo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data

@Entity

public class RDept {
	@Id
	private int deptno;
	@Column(length = 15)
	private String dname;
	@Column(length = 15)
	private String loc;

}
