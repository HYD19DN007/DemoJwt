package com.JwtDemo.demoJwt.Model.DAO.services;

import java.util.List;
import java.util.Optional;

import com.JwtDemo.demoJwt.Model.Pojo.RAddress;


public interface IRAddress {
	
	String insertAddress(RAddress A);

	String updateAddress(RAddress A, int addressid);

	List<RAddress> getAddresses();

	Optional<RAddress> getAddressById(int addressid);

	String deleteAddress(int addressid);

}
