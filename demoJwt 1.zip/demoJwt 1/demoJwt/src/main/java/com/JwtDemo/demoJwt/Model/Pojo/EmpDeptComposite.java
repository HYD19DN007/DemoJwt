package com.JwtDemo.demoJwt.Model.Pojo;

import java.time.LocalDate;

import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Data
@Embeddable
public class EmpDeptComposite {
	@ManyToOne
	@JoinColumn(name="empno")
	private REmp emp;
	@ManyToOne
	@JoinColumn(name="deptno")
	private RDept dept;
	private LocalDate startdate;
}
