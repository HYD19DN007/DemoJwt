package com.JwtDemo.demoJwt.Model.BL;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.JwtDemo.demoJwt.Model.DAO.serviceimpl.RSalaryServiceImpl;
import com.JwtDemo.demoJwt.Model.Pojo.RSalary;
import com.JwtDemo.demoJwt.Model.dto.Salarydto;


public class RSalaryBL {
	@Autowired
	 RSalaryServiceImpl rSalaryServiceImpl;
	
	public String addSalary(Salarydto S) {
		return rSalaryServiceImpl.addSalary(S);
		
	}
	public List<RSalary>getAllSalaries()
	{
		return rSalaryServiceImpl.getAllSalaries();
	}

}
