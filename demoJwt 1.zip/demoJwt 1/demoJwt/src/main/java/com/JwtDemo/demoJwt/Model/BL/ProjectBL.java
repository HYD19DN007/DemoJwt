package com.JwtDemo.demoJwt.Model.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.JwtDemo.demoJwt.Model.DAO.serviceimpl.ProjectServiceimpl;
import com.JwtDemo.demoJwt.Model.Pojo.Project;


public class ProjectBL {
@Autowired
ProjectServiceimpl projectServiceimpl;
public String insertProject(Project P)
{
	return projectServiceimpl.insertProject(P);
	
}
public List<Project> getallprojects()
{
	return projectServiceimpl.getallprojects();
}

public String UpdateProject(Project newp,int projectid)
{
	String S=projectServiceimpl.update(newp, projectid);
	return S;
}

public String DeleteProject(int projectid)
{
	String S=projectServiceimpl.Delete(projectid);
	return S;
}

}
