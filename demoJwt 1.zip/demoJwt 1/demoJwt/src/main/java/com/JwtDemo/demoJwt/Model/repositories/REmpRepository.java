package com.JwtDemo.demoJwt.Model.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.JwtDemo.demoJwt.Model.Pojo.REmp;

public interface REmpRepository extends JpaRepository<REmp, Integer> {

}
