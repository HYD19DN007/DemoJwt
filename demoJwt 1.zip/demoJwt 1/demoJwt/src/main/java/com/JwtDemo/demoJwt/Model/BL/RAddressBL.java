package com.JwtDemo.demoJwt.Model.BL;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.JwtDemo.demoJwt.Model.DAO.serviceimpl.RAddressServiceImpl;
import com.JwtDemo.demoJwt.Model.Pojo.RAddress;


public class RAddressBL {
	@Autowired
	RAddressServiceImpl rAddressServiceImpl;

	public String insertAddress(RAddress A) {
		return rAddressServiceImpl.insertAddress(A);
	}

	public String updateAddress(RAddress A, int addressid) {
		return rAddressServiceImpl.updateAddress(A, addressid);
	}

	public List<RAddress> getAddresses() {
		return rAddressServiceImpl.getAddresses();
	}

	public RAddress getAddressById(int addressid) {
		return rAddressServiceImpl.getAddressById(addressid).get();
	}

	public String deleteAddress(int addressid) {
		return rAddressServiceImpl.deleteAddress(addressid);
	}

}
