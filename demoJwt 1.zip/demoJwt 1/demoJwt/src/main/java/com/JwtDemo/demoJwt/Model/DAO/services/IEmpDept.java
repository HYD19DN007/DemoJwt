package com.JwtDemo.demoJwt.Model.DAO.services;

import java.util.List;

import com.JwtDemo.demoJwt.Model.Pojo.Emp_Dept;

public interface IEmpDept {
String insertEmpdept(Emp_Dept E);
List<Emp_Dept>getall();
}
