package com.JwtDemo.demoJwt.Model.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.JwtDemo.demoJwt.Model.Pojo.REmployee;

@Repository
public interface REmployeeRepository extends JpaRepository<REmployee, Integer> {

}
