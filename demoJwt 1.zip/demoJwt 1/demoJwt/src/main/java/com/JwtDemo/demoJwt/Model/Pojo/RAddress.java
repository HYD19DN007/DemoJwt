package com.JwtDemo.demoJwt.Model.Pojo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class RAddress {
	@Id
	private int addressid;
	@Column(length = 10)
	private String hno;
	@Column(length = 15)
	private String city;
	@Column(length = 10)
	private String picode;
}
