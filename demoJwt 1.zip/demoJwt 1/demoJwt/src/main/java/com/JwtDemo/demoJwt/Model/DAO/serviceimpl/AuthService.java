//package com.JwtDemo.demoJwt.Model.DAO.serviceimpl;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import com.JwtDemo.demoJwt.Model.DAO.services.IOurUser;
//import com.JwtDemo.demoJwt.Model.Pojo.OurUsers;
//import com.JwtDemo.demoJwt.Model.repositories.UserRepository;
//
//@Service
//	public class AuthService implements IOurUser {
//		@Autowired
//		UserRepository userRepo;
//		@Autowired
//		PasswordEncoder passwordEncoder;
//		
//
//		public String SaveUser(OurUsers user) {
//			System.out.println("Save Users");
//			user.setPassword(passwordEncoder.encode(user.getPassword()));
//			userRepo.save(user);
//			return "User Saved Successfully";
//		}
//
//
//		@Override
//		public List<OurUsers> getUsers() {
//			// TODO Auto-generated method stub
//			return userRepo.findAll();
//		}
//
//
//		@Override
//		public Optional<OurUsers> FetchUserByEmail(String email) {
//			// TODO Auto-generated method stub
//			return userRepo.findByEmail(email);
//		}
//
//		
//}
//
