package com.JwtDemo.demoJwt;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.JwtDemo.demoJwt.Model.BL.EmpDeptBL;
import com.JwtDemo.demoJwt.Model.BL.ProjectBL;
import com.JwtDemo.demoJwt.Model.BL.RAddressBL;
import com.JwtDemo.demoJwt.Model.BL.REmployeeBL;
import com.JwtDemo.demoJwt.Model.BL.RSalaryBL;

@Configuration
public class ConfigClass {
	@Bean
	public ProjectBL projectBl() {
		return new ProjectBL();

	}

	@Bean
	public REmployeeBL rEmployeeBL() {
		return new REmployeeBL();

	}

	@Bean
	public RAddressBL rAddressBL() {
		return new RAddressBL();
	}

	@Bean
	public RSalaryBL rSalaryBL() {
		return new RSalaryBL();
	}
	@Bean 
	public EmpDeptBL empDeptBL()
	{
		return new EmpDeptBL();
	}
	
	

}
