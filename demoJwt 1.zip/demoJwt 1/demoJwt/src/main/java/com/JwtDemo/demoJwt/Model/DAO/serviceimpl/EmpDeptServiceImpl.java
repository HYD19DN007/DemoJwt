package com.JwtDemo.demoJwt.Model.DAO.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.JwtDemo.demoJwt.Model.DAO.services.IEmpDept;
import com.JwtDemo.demoJwt.Model.Pojo.Emp_Dept;
import com.JwtDemo.demoJwt.Model.Pojo.REmp;
import com.JwtDemo.demoJwt.Model.repositories.EmpDeptRepository;
import com.JwtDemo.demoJwt.Model.repositories.RDeptRepository;
import com.JwtDemo.demoJwt.Model.repositories.REmpRepository;
@Service
public class EmpDeptServiceImpl implements IEmpDept {
	@Autowired
	EmpDeptRepository empDeptRepository;
	@Autowired
	REmpRepository rEmpRepository;
	@Autowired
	RDeptRepository rDeptRepository;
	
	@Override
	public String insertEmpdept(Emp_Dept E) {
		//Optional<REmp>emp=rEmpRepository.findById(E.)
	return null;
	
	
	
	
	}

	@Override
	public List<Emp_Dept> getall() {
		// TODO Auto-generated method stub
		return empDeptRepository.findAll();
	}

}
