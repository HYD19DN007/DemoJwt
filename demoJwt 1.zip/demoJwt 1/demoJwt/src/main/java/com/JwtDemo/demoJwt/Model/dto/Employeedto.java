package com.JwtDemo.demoJwt.Model.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Employeedto {
	private Integer empno;
	private String ename;
	private String gender;
	private int addid;//100

}
