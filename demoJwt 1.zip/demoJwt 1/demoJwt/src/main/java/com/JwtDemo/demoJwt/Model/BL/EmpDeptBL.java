package com.JwtDemo.demoJwt.Model.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.JwtDemo.demoJwt.Model.DAO.serviceimpl.EmpDeptServiceImpl;
import com.JwtDemo.demoJwt.Model.Pojo.Emp_Dept;

public class EmpDeptBL {
@Autowired
EmpDeptServiceImpl empDeptServiceImpl;
public List<Emp_Dept>getall()
{
	return empDeptServiceImpl.getall();
}
}
