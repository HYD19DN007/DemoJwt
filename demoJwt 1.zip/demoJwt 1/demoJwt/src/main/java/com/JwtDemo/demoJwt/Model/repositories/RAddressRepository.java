package com.JwtDemo.demoJwt.Model.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.JwtDemo.demoJwt.Model.Pojo.RAddress;


@Repository
public interface RAddressRepository extends JpaRepository<RAddress, Integer>{

}
