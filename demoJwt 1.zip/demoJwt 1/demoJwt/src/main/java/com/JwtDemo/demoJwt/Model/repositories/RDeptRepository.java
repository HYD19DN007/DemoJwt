package com.JwtDemo.demoJwt.Model.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.JwtDemo.demoJwt.Model.Pojo.RDept;

public interface RDeptRepository extends JpaRepository<RDept, Integer> {

}
