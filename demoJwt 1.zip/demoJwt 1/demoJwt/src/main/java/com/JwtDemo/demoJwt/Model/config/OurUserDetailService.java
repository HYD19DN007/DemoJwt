package com.JwtDemo.demoJwt.Model.config;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.JwtDemo.demoJwt.Model.Pojo.OurUsers;
import com.JwtDemo.demoJwt.Model.repositories.UserRepository;

public class OurUserDetailService implements UserDetailsService {

	
	@Autowired
	UserRepository userRepository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			
		Optional<OurUsers>Op= userRepository.findByEmail(username);
		System.out.println(Op.get().getEmail()+ " "+Op.get().getPassword()+ " "+Op.get().getRole());
		return Op.map(OurUserDetails::new).orElseThrow(()->new
					UsernameNotFoundException("Username not found"));
			}

}
