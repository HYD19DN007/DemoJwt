package com.JwtDemo.demoJwt.Model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Salarydto {
	private Integer empno;
	private Integer basic;
}
