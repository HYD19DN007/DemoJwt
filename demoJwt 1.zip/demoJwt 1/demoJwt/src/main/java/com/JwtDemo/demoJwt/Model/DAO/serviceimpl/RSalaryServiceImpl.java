package com.JwtDemo.demoJwt.Model.DAO.serviceimpl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.JwtDemo.demoJwt.Model.DAO.services.IRSalary;
import com.JwtDemo.demoJwt.Model.Pojo.REmployee;
import com.JwtDemo.demoJwt.Model.Pojo.RSalary;
import com.JwtDemo.demoJwt.Model.dto.Salarydto;
import com.JwtDemo.demoJwt.Model.repositories.REmployeeRepository;
import com.JwtDemo.demoJwt.Model.repositories.RSalaryRepository;


@Service
public class RSalaryServiceImpl implements IRSalary {
	@Autowired
	REmployeeRepository rEmployeeRepository;
	@Autowired
	RSalaryRepository rSalaryRepository;

	@Override
	public String addSalary(Salarydto S) {
		Optional<REmployee> emp = rEmployeeRepository.findById(S.getEmpno());
				
		if (emp.isPresent()) {
			Optional<RSalary> sal = rSalaryRepository.findById(S.getEmpno());
			if (sal.isPresent()) {
				return "Employee's Salary already present";
			} else {
				RSalary RS=new RSalary();
				//RS.setEmpno(S.getEmpno());
				RS.setEmployee(emp.get());
				RS.setBasic(S.getBasic());
				rSalaryRepository.save(RS);
				return "Salary Saved Successfully";
			}
		} else {
			return "Employee no does not exist";
		}
	}

	@Override
	public List<RSalary> getAllSalaries() {
		// TODO Auto-generated method stub
		return rSalaryRepository.findAll();
	}

}
