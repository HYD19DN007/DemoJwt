package com.JwtDemo.demoJwt.Model.DAO.serviceimpl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.JwtDemo.demoJwt.Model.DAO.services.IOurUser;
import com.JwtDemo.demoJwt.Model.Pojo.OurUsers;
import com.JwtDemo.demoJwt.Model.repositories.UserRepository;



@Service
public class UserServiceImpl implements IOurUser
{
	@Autowired
	UserRepository userRepository;
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Override
	public String SaveUser(OurUsers ourusers) {
		// TODO Auto-generated method stub
		ourusers.setPassword(passwordEncoder.encode(ourusers.getPassword()));
		ourusers.setRole(ourusers.getRole().toUpperCase());
		 userRepository.save(ourusers);
		 return "User created";
	}

	@Override
	public List<OurUsers> AllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public Optional<OurUsers> GetUserByEmail(String email) {
		// TODO Auto-generated method stub
		return userRepository.findByEmail(email);
	}

	
}
