package com.JwtDemo.demoJwt.Controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/Sample")
public class SampleController {

	static List<String> list=new ArrayList<String>();
	public SampleController()
	{
		list.add("One");
		list.add("Two");
		list.add("Three");
	}
	
	
	@GetMapping("/getall")
	public List<String>  getStrings()
	{
		return list;
	}
	
	@GetMapping("/get/{id1}/{id2}")
	public  String   getString(@PathVariable("id1") int id1,@PathVariable("id2") int id2)//http://localhost:9091/Sample/get/1
	{
		return list.get(id1)+ " " +list.get(id2);
	}
	@GetMapping("/getstr")
	public String getStr(@RequestParam("a") int i,@RequestParam("b") int j)//http://localhost:9091/Sample/getstr?a=1
	{
		return list.get(i)+ " "+list.get(j);
	}
	@PostMapping("/add")//Insert the data// We cannot test in broweser
	public String addString(@RequestBody  String S)
	{
		list.add(S);
		return "added";
		
	}
	@PutMapping("/Update/{id}")
	public String update(@RequestBody String S,@PathVariable("id") int  i)
	{
		list.set(i,S);
		return "Updatd";
		
	}
	@DeleteMapping("/Delete/{id}")
	public String Delete(@PathVariable("id") int  i)
	{
		list.remove(i);
		return "Delete";
		
	}
	
	
	
	
}
