package com.JwtDemo.demoJwt.Controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.JwtDemo.demoJwt.Model.DAO.serviceimpl.JwtService;
import com.JwtDemo.demoJwt.Model.DAO.serviceimpl.UserServiceImpl;
import com.JwtDemo.demoJwt.Model.Pojo.OurUsers;
import com.JwtDemo.demoJwt.Model.dto.UserRequestDto;
import com.JwtDemo.demoJwt.Model.repositories.UserRepository;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/auth")

public class AuthController {
	@Autowired
	UserServiceImpl userServiceImpl;
	@Autowired
	AuthenticationManager authenticationManager;
	@Autowired
	UserRepository userRepository;
	@Autowired
	JwtService jwtService;
	@Autowired
	UserDetailsService userDetailsService;
	@Autowired
	PasswordEncoder passwordEncoder;
	@GetMapping("/getusers")
	//@PreAuthorize("hasAuthority('USER')")
	public List<OurUsers> getuser()
	{
		return userServiceImpl.AllUsers();
	}
	@PostMapping("/save")
	public String SaveUser(@RequestBody OurUsers ourUsers)
	{
		return userServiceImpl.SaveUser(ourUsers);
	}
	@PostMapping("/Validate")
	public ResponseEntity<Map<String,String>> LoginValidate(@RequestBody UserRequestDto userdto)
	{
		Map<String,String> usermap=new HashMap<String, String>();
		//Fetching from database 
		Optional<OurUsers>Op= userServiceImpl.GetUserByEmail(userdto.getEmail());
		//System.out.println(Op.get() + "hhhhhhhhhhhhhhhhhhhhh");
		  if(Op.isEmpty())
		  {
			  usermap.put("error", "User not found");
			  return new ResponseEntity<Map<String,String>>(usermap,HttpStatus.BAD_REQUEST);
		  }
		  else if(!passwordEncoder.matches(userdto.getPassword(), Op.get().getPassword()))
		  {
			  usermap.put("error", "Password not correct");
			  return new ResponseEntity<Map<String,String>>(usermap,HttpStatus.BAD_REQUEST);
		  }
		  else
		   {
			  Authentication authentication=authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userdto.getEmail(),userdto.getPassword()));
			  if(authentication.isAuthenticated())
			  {
				  System.out.println(Op.get().getRole());
				  usermap.put("role",Op.get().getRole() );
				  usermap.put("token",jwtService.generateToken(authentication.getName(), authentication.getAuthorities().toArray()[0].toString()));
				  return new ResponseEntity<Map<String,String>>(usermap,HttpStatus.OK);
			  }
			  
		   }
		return new ResponseEntity<Map<String,String>>(usermap,HttpStatus.OK);
	}
	
	 @GetMapping("/Validatetoken")
	    public String validateToken(@RequestParam("Authorization") String token) {
	      System.out.println("In Validation Token");
		     if(jwtService.validateToken(token))
		     return jwtService.extractRoleFromToken(token);
		     else
		    	return  "Not Valid";
	 }
	 @GetMapping("/Logout")
	 public ResponseEntity<String> logout(HttpServletRequest request) {
	     request.getSession().invalidate(); // ✅ Invalidate the session
	     return ResponseEntity.ok("Session ended successfully");
	 } 
	   
	
}
