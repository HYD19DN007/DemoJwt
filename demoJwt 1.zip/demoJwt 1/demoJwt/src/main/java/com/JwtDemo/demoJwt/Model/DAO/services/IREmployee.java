package com.JwtDemo.demoJwt.Model.DAO.services;

import java.util.List;
import java.util.Optional;

import com.JwtDemo.demoJwt.Model.Pojo.REmployee;
import com.JwtDemo.demoJwt.Model.dto.Employeedto;


public interface IREmployee {
	String AddEmployee(Employeedto E);

	String UpdateEmployee(REmployee newemp, int empno);

	String deleteEmployee(int empno);

	List<REmployee> getall();

	Optional<REmployee> getById(int empno);
}
