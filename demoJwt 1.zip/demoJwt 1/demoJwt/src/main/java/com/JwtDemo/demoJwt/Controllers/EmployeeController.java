package com.JwtDemo.demoJwt.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JwtDemo.demoJwt.Model.BL.REmployeeBL;
import com.JwtDemo.demoJwt.Model.dto.Employeedto;


@RestController
@RequestMapping("/emp")
public class EmployeeController {
	@Autowired
	REmployeeBL rEmployeeBL;

	@PostMapping("/addemp")
	public String addEmp(@RequestBody Employeedto E) {
		return rEmployeeBL.addEmployee(E);
	}
}
