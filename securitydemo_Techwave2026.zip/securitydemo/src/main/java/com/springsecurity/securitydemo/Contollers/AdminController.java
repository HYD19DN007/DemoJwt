package com.springsecurity.securitydemo.Contollers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/adminemp")
public class AdminController {
	private static List<String> list = new ArrayList<String>();

	public AdminController() {
		list.add("Karthik");
		list.add("Krishna");
		list.add("Kavya");
	}
	//@PreAuthorize("hasRole('ADMIN')")    //MANAGER,ADMIN,USER
	@GetMapping("/getall")
	
	public List<String> getall() {
	System.out.println("Hello");
		return list;
	}
	//@PreAuthorize("hasAnyRole('ADMIN','USER')")
	@GetMapping("/getbyid/{id}")
	public String getbyid(@PathVariable("id") int id) {
		return list.get(id);
	}
}
