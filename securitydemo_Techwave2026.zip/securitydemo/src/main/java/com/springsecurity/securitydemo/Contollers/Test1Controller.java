package com.springsecurity.securitydemo.Contollers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test/test1")
public class Test1Controller {

}
