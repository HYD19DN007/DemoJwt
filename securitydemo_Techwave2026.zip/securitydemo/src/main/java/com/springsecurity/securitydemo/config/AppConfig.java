package com.springsecurity.securitydemo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.springsecurity.securitydemo.Models.ServiceImpl.JWTService;
import com.springsecurity.securitydemo.Models.ServiceImpl.LoginUserdtailsservice;
import com.springsecurity.securitydemo.filter.JwtAuthenticationFilter;

import jakarta.servlet.http.HttpServletResponse;


@Configuration
//@EnableMethodSecurity
public class AppConfig {
	private final JWTService jwtService;
	@Autowired
	JwtauthenticationEntryPoint  authenticationEntryPoint;
	@Autowired
	CustomAccessDeniedHandler customAccessDeniedHandler;
	public AppConfig(JWTService jwtService)
	{
		super();
		this.jwtService=jwtService;
	}
	
//	@Bean
//	public UserDetailsService userDetailsService() {
//		UserDetails userDetails = User.builder().username("Hyderabad").password(passwordEncoder().encode("Admin#123"))
//				.roles("ADMIN").build();
//		UserDetails adminDetails = User.builder().username("Microsoft").password(passwordEncoder().encode("Admin#123"))
//				.roles("USER").build();
//		return new InMemoryUserDetailsManager(userDetails, adminDetails);
//	}

//PasswordEncoder passwordEncoder=new BCryptPasswordEncoder();
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

//used for provided url/controller level security
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		return http.csrf(csrf -> csrf.disable())
				.authorizeHttpRequests(auth -> auth
						.requestMatchers("/auth/**").permitAll()
						.requestMatchers("/adminemp/**").hasAuthority("ADMIN")
						.requestMatchers("/useremp/**").hasAuthority("USER")
						.anyRequest().authenticated())
				.httpBasic(Customizer.withDefaults())
				.sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
				.authenticationProvider(authenticationProvider())
				.addFilterBefore(jwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
//				.
				//.exceptionHandling
//				(
//						ex->ex
//						.authenticationEntryPoint
//						(
//							(request,response,authException)->
//							{
//							response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
//							response.setContentType("application/json");
//							response.getWriter().write
//								("""
//									"status":401,
//									"message":"Please enter the credentials"
//								""");
//							}
//						)
//						
//						.accessDeniedHandler
//						(
//							(request,response,authException)->
//							{
//							response.setStatus(HttpServletResponse.SC_FORBIDDEN);
//							response.setContentType("application/json");
//							response.getWriter().write
//								("""
//									"status":403,
//									"message":"You are not authorised to view this page"
//								""");
//							}
//						)
//						
//				)
			
				
				.exceptionHandling(ex -> ex
	                    .authenticationEntryPoint(authenticationEntryPoint)
	                    .accessDeniedHandler(customAccessDeniedHandler))
				
				
				.build();
				
				
		

	}

//	@Bean 
//	public JWTService jwtService()
//	{
//		return new JWTService();
//	}
	
	@Bean 
	public JwtAuthenticationFilter jwtAuthenticationFilter()
	{
		return new JwtAuthenticationFilter(userDetailsService(),jwtService);
	}
	@Bean 
	public UserDetailsService userDetailsService() 
	{
		System.out.println("UserDetailServices");		
		return new LoginUserdtailsservice();
	}

	@Bean
	public AuthenticationProvider authenticationProvider() 
	{
		System.out.println("Authentication Provider");
		DaoAuthenticationProvider provider=new DaoAuthenticationProvider(userDetailsService());
		provider.setPasswordEncoder(passwordEncoder());
		return provider;
	}
	
	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration config)
	{
		System.out.println("AuthenritcationManager");
		return config.getAuthenticationManager();
	}

	
	
	
	
	}
