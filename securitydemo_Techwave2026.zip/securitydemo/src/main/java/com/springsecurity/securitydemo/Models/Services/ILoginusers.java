package com.springsecurity.securitydemo.Models.Services;

import java.util.List;
import java.util.Optional;

import com.springsecurity.securitydemo.Models.POJO.Loginusers;

public interface ILoginusers {
String CreateUser(Loginusers L);
List<Loginusers>getUsers();
Optional<Loginusers>getByEmail(String email);	
}
