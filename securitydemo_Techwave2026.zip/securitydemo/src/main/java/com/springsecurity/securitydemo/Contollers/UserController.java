package com.springsecurity.securitydemo.Contollers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/useremp")
public class UserController {
	private static List<String> list = new ArrayList<String>();

	public UserController() {
		list.add("Jagadish");
		list.add("Jayath");
		list.add("Varun");
		list.add("Akhila");
	}
	//@PreAuthorize("hasRole('USER')")
	@GetMapping("/getall")
	public List<String>getall()
	{
		return list;
	}
	//@PreAuthorize("hasAnyRole('USER','ADMIN')")
	@GetMapping("/getbyid/{id}")
	public String getbyid(@PathVariable("id") int id)
	{
		return list.get(id);
	}
}
