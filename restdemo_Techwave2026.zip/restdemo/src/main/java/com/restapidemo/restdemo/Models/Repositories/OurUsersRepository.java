package com.restapidemo.restdemo.Models.Repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.restapidemo.restdemo.Models.POJO.OurUsers;

@Repository
public interface OurUsersRepository extends JpaRepository<OurUsers, Long> {
	@Query("select o from OurUsers o where o.email=?1")
	Optional<OurUsers> getByEmail(String email);

}
