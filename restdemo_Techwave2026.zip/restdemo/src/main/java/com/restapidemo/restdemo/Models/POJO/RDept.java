package com.restapidemo.restdemo.Models.POJO;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
//@Table(name="dept")
public class RDept {
	@Id
	private Integer deptno;//Reference key
	@Column(length = 10)
	private String dname;
	@Column(length = 15)
	private String loc;
//	@OneToMany
//	@JoinColumn(name="deptno",referencedColumnName = "deptno")
//	private List<REmployee> rEmployee;
}
