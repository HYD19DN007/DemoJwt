package com.restapidemo.restdemo.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data

public class EmpDeptdetailsdto {
private int empno;
private String ename;
private int deptno;
private String dname;
private LocalDate startdate;
private LocalDate enddate;
}
