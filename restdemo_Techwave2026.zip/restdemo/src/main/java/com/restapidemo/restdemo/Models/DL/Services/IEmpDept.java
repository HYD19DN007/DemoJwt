package com.restapidemo.restdemo.Models.DL.Services;

import java.util.List;

import com.restapidemo.restdemo.Models.POJO.Emp_Dept;
import com.restapidemo.restdemo.dto.EmpDeptDto;
import com.restapidemo.restdemo.dto.EmpDeptdetailsdto;

public interface IEmpDept {
	String adddeptallocation(EmpDeptDto E);
	List<Emp_Dept> getall();
	List<EmpDeptDto>getdetails();
	List<EmpDeptdetailsdto>getalldetails();

}
