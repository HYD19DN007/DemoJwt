package com.restapidemo.restdemo.Models.DL.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restapidemo.restdemo.Models.DL.Services.IRSalary;
import com.restapidemo.restdemo.Models.POJO.REmployee;
import com.restapidemo.restdemo.Models.POJO.RSalary;
import com.restapidemo.restdemo.Models.Repositories.REmployeeRepository;
import com.restapidemo.restdemo.Models.Repositories.RSalaryRepository;
import com.restapidemo.restdemo.dto.EmpDeptSalDto;
import com.restapidemo.restdemo.dto.EmpSalDeptDto;
import com.restapidemo.restdemo.dto.Salarydto;

@Service
public class RSalaryServiceImpl implements IRSalary {
	@Autowired
	REmployeeRepository rEmployeeRepository;
	@Autowired
	RSalaryRepository rSalaryRepository;

	@Override
	public String addSalary(Salarydto S) {
		Optional<REmployee> emp = rEmployeeRepository.findById(S.getEmpno());
				
		if (emp.isPresent()) {
			Optional<RSalary> sal = rSalaryRepository.findById(S.getEmpno());
			if (sal.isPresent()) {
				return "Employee's Salary already present";
			} else {
				RSalary RS=new RSalary();
				//RS.setEmpno(S.getEmpno());
				RS.setEmployee(emp.get());
				RS.setBasic(S.getBasic());
				rSalaryRepository.save(RS);
				return "Salary Saved Successfully";
			}
		} else {
			return "Employee no does not exist";
		}
	}

	@Override
	public List<RSalary> getAllSalaries() {
		// TODO Auto-generated method stub
		return rSalaryRepository.findAll();
	}

	@Override
	public List<EmpDeptSalDto> getall(int b,String c) {
		// TODO Auto-generated method stub
		return rSalaryRepository.getall(b,c);
	}

	
}
