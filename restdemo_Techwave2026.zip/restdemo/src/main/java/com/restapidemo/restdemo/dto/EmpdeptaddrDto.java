package com.restapidemo.restdemo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class EmpdeptaddrDto {
	private int empno;
	private String ename;
	private String gender;
	private String dname;
	private String hno;
	private String city;
	private String picode;

}
