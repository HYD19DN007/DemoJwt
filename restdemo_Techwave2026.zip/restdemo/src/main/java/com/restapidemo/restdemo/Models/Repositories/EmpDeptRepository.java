package com.restapidemo.restdemo.Models.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.restapidemo.restdemo.Models.POJO.EmpDeptComposite;
import com.restapidemo.restdemo.Models.POJO.Emp_Dept;
import com.restapidemo.restdemo.dto.EmpDeptDto;
import com.restapidemo.restdemo.dto.EmpDeptdetailsdto;
@Repository
public interface EmpDeptRepository extends JpaRepository<Emp_Dept, EmpDeptComposite> {
  
	//Select * empno,deptno,startdate,endate
	
	
	//1,'ram',10,'sales',2026-09-01,2026-12-10
	//1,'ram',10,'sales',2026-09-01,2026-12-10
	//Select * from emp
	//select  empno  from remp e;
	@Query("""
			select new com.restapidemo.restdemo.dto.EmpDeptDto(e.empdept.emp.empno,
			e.empdept.dept.deptno,
			e.empdept.startdate,
			e.enddate)			
			from Emp_Dept e
			""")
		List<EmpDeptDto> getdetails();
	
	
	@Query("""
			select new com.restapidemo.restdemo.dto.EmpDeptdetailsdto(e.empdept.emp.empno,
			e.empdept.emp.ename,
			e.empdept.dept.deptno,
			e.empdept.dept.dname,
			e.empdept.startdate,
			e.enddate
			) from Emp_Dept e
			""")
	List<EmpDeptdetailsdto>getalldetails();
	
	
	//EmpDeptdetailsdto E=new EmpDeptdetailsdto(1,'EE',20,'sales',0);
	
	
}
//1
//10
