package com.restapidemo.restdemo.Models.POJO;

import java.time.LocalDate;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class Emp_Dept {
	@EmbeddedId
	private EmpDeptComposite empdept = new EmpDeptComposite();
	private LocalDate enddate;

}
