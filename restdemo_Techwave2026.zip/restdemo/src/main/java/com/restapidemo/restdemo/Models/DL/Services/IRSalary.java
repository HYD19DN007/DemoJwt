package com.restapidemo.restdemo.Models.DL.Services;

import java.util.List;

import com.restapidemo.restdemo.Models.POJO.RSalary;
import com.restapidemo.restdemo.dto.EmpDeptSalDto;
import com.restapidemo.restdemo.dto.EmpSalDeptDto;
import com.restapidemo.restdemo.dto.Salarydto;

public interface IRSalary {
String addSalary(Salarydto S);
List<RSalary>getAllSalaries();
List<EmpDeptSalDto>getall(int b,String c);

}

