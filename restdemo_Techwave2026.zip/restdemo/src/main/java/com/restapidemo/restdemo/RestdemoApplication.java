package com.restapidemo.restdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.restapidemo.restdemo.Models.BL.CustomerBL;
import com.restapidemo.restdemo.Models.BL.EmpDeptBL;
import com.restapidemo.restdemo.Models.BL.EmpdataBL;
import com.restapidemo.restdemo.Models.BL.OurUsersBL;
import com.restapidemo.restdemo.Models.BL.ProjectBL;
import com.restapidemo.restdemo.Models.BL.RAddressBL;
import com.restapidemo.restdemo.Models.BL.REmployeeBL;
import com.restapidemo.restdemo.Models.BL.RSalaryBL;
import com.restapidemo.restdemo.Models.POJO.RSalary;

@SpringBootApplication
public class RestdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestdemoApplication.class, args);
	}

	@Bean
	public ProjectBL projectBl() {
		return new ProjectBL();

	}

	@Bean
	public EmpdataBL empdataBL()
	{
		return new EmpdataBL();
	}
	
	@Bean
	public REmployeeBL rEmployeeBL() {
		return new REmployeeBL();

	}

	@Bean
	public RAddressBL rAddressBL() {
		return new RAddressBL();
	}

	@Bean
	public RSalaryBL rSalaryBL() {
		return new RSalaryBL();
	}
	@Bean
	public EmpDeptBL empDeptBL()
	{
		return new EmpDeptBL();
	}
	@Bean
	public OurUsersBL ourUsersBL()
	{
		return new OurUsersBL();
	}
	
	@Bean
	public PasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
	@Bean
	public CustomerBL customerBL()
	{
		return new CustomerBL();
	}
}
