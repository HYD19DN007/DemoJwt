package com.restapidemo.restdemo.Models.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.restapidemo.restdemo.Models.POJO.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long>{

}
