package com.restapidemo.restdemo.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.restapidemo.restdemo.Models.BL.REmployeeBL;
import com.restapidemo.restdemo.Models.POJO.REmployee;
import com.restapidemo.restdemo.dto.EmpdeptaddrDto;
import com.restapidemo.restdemo.dto.Employeedto;

@RestController
@RequestMapping("/emp")
public class EmployeeController {
	@Autowired
	REmployeeBL rEmployeeBL;

	@PostMapping("/addemp")
	public String addEmp(@RequestBody Employeedto E) {
		return rEmployeeBL.addEmployee(E);
	}
	@GetMapping("/getbyname/{ename}")
	public List<REmployee> getbyname(@PathVariable("ename") String ename)
	{
		return rEmployeeBL.getByname(ename);
	}
	@GetMapping("/getbygender")
	public List<REmployee> getbygen(@RequestParam("g") String gender)
	{
		return rEmployeeBL.getByGen(gender);
	}
	@GetMapping("/getalldetails")
	public List<EmpdeptaddrDto> getalldetails()
	{
		return rEmployeeBL.getalldetails();
	}

}
