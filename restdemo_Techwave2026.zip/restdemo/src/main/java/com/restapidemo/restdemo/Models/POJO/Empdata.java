package com.restapidemo.restdemo.Models.POJO;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NamedQueries({
	@NamedQuery
	(
			name="Empdata.getbyJob",
			query="select e from Empdata e where e.job=?1"
			),
	@NamedQuery
	(
			name="Empdata.getbyDeptno",
			query="select e from Empdata e where e.deptno=?1"
			),
	@NamedQuery
	(
			name="Empdata.getwithdname",
			query="select  new com.restapidemo.restdemo.dto.EmpDeptwithNQDto("+
					"e.empno,e.ename,e.sal,d.dname)"+
					" from Empdata e inner join RDept d on "+ 
					"e.deptno=d.deptno"		
			)

})


@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class Empdata {
	@Id
	
	private int empno;
	@Column(length = 10)
	private String ename;
	@Column(length = 10)
	private String job;
	private Integer mgr;
	private LocalDate hiredate;
	private Integer sal;
	private Integer comm;
	private Integer deptno;
	
	

}
