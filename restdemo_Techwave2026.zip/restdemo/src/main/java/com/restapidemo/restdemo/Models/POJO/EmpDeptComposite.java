package com.restapidemo.restdemo.Models.POJO;

import java.time.LocalDate;

import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Data
@Embeddable// create a composite class
public class EmpDeptComposite {

	@ManyToOne
	@JoinColumn(name="empno")
	private REmp emp;
	@ManyToOne
	@JoinColumn(name="deptno")
	private RDept dept;
	private LocalDate startdate;
	
}
