package com.restapidemo.restdemo.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restapidemo.restdemo.Models.BL.EmpdataBL;
import com.restapidemo.restdemo.Models.POJO.Empdata;
import com.restapidemo.restdemo.dto.EmpDeptwithNQDto;
import com.restapidemo.restdemo.dto.Sumsal;

@RestController
@RequestMapping("/empdata")
public class EmpdataController {
	@Autowired
	EmpdataBL empdataBL;
	
	@GetMapping("getbyid/{id}")
	public Empdata getById(@PathVariable("id") int id)
	{
		return empdataBL.getById(id);
	}
	
	@GetMapping("/count")
	public int getcount() {
		return empdataBL.getCount();
	}
	@GetMapping("/countdeptno/{deptno}")
	public int getcountbydeptno(@PathVariable("deptno") int deptno) {
		return empdataBL.getCountbydeptno(deptno);
	}
	@GetMapping("/countsal/{S}")
	public int getcountbysal(@PathVariable("S") int S) {
		return empdataBL.getCountbySal(S);
	}
	@GetMapping("/sumsal")
	public List<Sumsal> gesumbysal() {
		return empdataBL.getSumofSalaries();
	}
	@GetMapping("/getbyJob/{J}")
	public List<Empdata> getbyjob(@PathVariable("J") String J) {
		return empdataBL.getbyJob(J);
	}
	@GetMapping("/getbyDname")
	public List<EmpDeptwithNQDto> getbyDname() {
		return empdataBL.getwithdeptname();
	}

}
