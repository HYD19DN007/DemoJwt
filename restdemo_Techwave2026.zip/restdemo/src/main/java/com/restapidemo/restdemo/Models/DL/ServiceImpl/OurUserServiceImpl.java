package com.restapidemo.restdemo.Models.DL.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.restapidemo.restdemo.Models.DL.Services.IOurUsers;
import com.restapidemo.restdemo.Models.POJO.OurUsers;
import com.restapidemo.restdemo.Models.Repositories.OurUsersRepository;
import com.restapidemo.restdemo.dto.UserRequestDto;

@Service
public class OurUserServiceImpl implements IOurUsers {
	@Autowired
	OurUsersRepository ourUsersRepository;
	@Autowired
	PasswordEncoder passwordEncoder;

	@Override
	public String CreateUser(UserRequestDto U) {
		Optional<OurUsers> ourusers = ourUsersRepository.getByEmail(U.getEmail());
		if (ourusers.isPresent())
			return "User exists";
		else {
			OurUsers user = new OurUsers();
			user.setEmail(U.getEmail());
			user.setRole(U.getRole());
			user.setPassword(passwordEncoder.encode(U.getPassword()));
			ourUsersRepository.save(user);
			return "Saved User";

		}
	}

	@Override
	public List<OurUsers> getall() {
		// TODO Auto-generated method stub
		return ourUsersRepository.findAll();
	}

	@Override
	public String ValidateUser(UserRequestDto userdto) {
		Optional<OurUsers> user = ourUsersRepository.getByEmail(userdto.getEmail());
		System.out.println(userdto);
		System.out.println(user);
		if (user.isPresent()) {
			boolean b = passwordEncoder.matches(userdto.getPassword(), user.get().getPassword());
			if (b)
				return "Success";
			else
				return "Success failed";
		} else
			return "No user found";

		// TODO Auto-generated method stub
	}

}
