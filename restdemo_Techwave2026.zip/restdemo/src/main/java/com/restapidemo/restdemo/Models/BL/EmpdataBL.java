package com.restapidemo.restdemo.Models.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.restapidemo.restdemo.Models.DL.ServiceImpl.EmpdataServiceImpl;
import com.restapidemo.restdemo.Models.POJO.Empdata;
import com.restapidemo.restdemo.dto.EmpDeptwithNQDto;
import com.restapidemo.restdemo.dto.Sumsal;

public class EmpdataBL {
@Autowired
EmpdataServiceImpl empdataServiceImpl;
	
	public int getCount() {
		// TODO Auto-generated method stub
		return empdataServiceImpl.getCount();
	}
	public int getCountbydeptno(int deptno) {
		// TODO Auto-generated method stub
		return empdataServiceImpl.getCountBydeptno(deptno);
	}
	public int getCountbySal(int S) 
	
	{// TODO Auto-generated method stub
		return empdataServiceImpl.getCountBySalary(S);
	}
	public List<Sumsal> getSumofSalaries() {
		// TODO Auto-generated method stub
		return empdataServiceImpl.getSumofSalaries();
	}
	public List<Empdata> getbyJob(String J) {
		// TODO Auto-generated method stub
		return empdataServiceImpl.getbyJob(J);
	}
	public List<EmpDeptwithNQDto>getwithdeptname()
	{
		return empdataServiceImpl.getwithDeptname();
	}
	public Empdata getById(int id) {
	return empdataServiceImpl.getById(id);
	}
	
}
