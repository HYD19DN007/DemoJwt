package com.restapidemo.restdemo.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restapidemo.restdemo.Models.BL.ProjectBL;
import com.restapidemo.restdemo.Models.POJO.Project;

@RestController
@RequestMapping("/Project")
public class ProjectController {

	@Autowired
	ProjectBL projectBL;
	
	@PostMapping("/addproject")
	public String addProject(@RequestBody Project P)
	{
		return projectBL.insertProject(P);
	}
	@GetMapping("/getall")
	public List<Project> getAll()
	{
		return projectBL.getallprojects();
	}
	
	@PutMapping("/updateroject/{pid}")
	public String update(@RequestBody Project P, @PathVariable("pid") int pid)
	{
		if(P.getProjectid()==pid)
			return projectBL.UpdateProject(P, pid);
		else
			return "ProjectId not valid";
	}
	
	@DeleteMapping("/delete/{pid}")
	public String Delete(@PathVariable("pid") int pid)
	{
		return projectBL.DeleteProject(pid);
		
			
	}
}
