package com.restapidemo.restdemo.Models.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.restapidemo.restdemo.Models.DL.ServiceImpl.RSalaryServiceImpl;
import com.restapidemo.restdemo.Models.POJO.RSalary;
import com.restapidemo.restdemo.dto.EmpDeptSalDto;
import com.restapidemo.restdemo.dto.EmpSalDeptDto;
import com.restapidemo.restdemo.dto.Salarydto;

public class RSalaryBL {
	@Autowired
	 RSalaryServiceImpl rSalaryServiceImpl;
	
	public String addSalary(Salarydto S) {
		return rSalaryServiceImpl.addSalary(S);
		
	}
	public List<RSalary>getAllSalaries()
	{
		return rSalaryServiceImpl.getAllSalaries();
	}
	public List<EmpDeptSalDto> getall(int b,String c) {
		// TODO Auto-generated method stub
		return rSalaryServiceImpl.getall(b,c);
	}


}
