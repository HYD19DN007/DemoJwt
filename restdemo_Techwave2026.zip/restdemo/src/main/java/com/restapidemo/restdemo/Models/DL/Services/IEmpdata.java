package com.restapidemo.restdemo.Models.DL.Services;

import java.util.List;

import com.restapidemo.restdemo.Models.POJO.Empdata;
import com.restapidemo.restdemo.dto.EmpDeptwithNQDto;
import com.restapidemo.restdemo.dto.Sumsal;

public interface IEmpdata {
int getCount();
int getCountBydeptno(int deptno);
int getCountBySalary(int S);
List<Sumsal> getSumofSalaries();
List<Empdata> getbyJob(String J);
List<EmpDeptwithNQDto>getwithDeptname();
Empdata getById(int id);


}
