package com.restapidemo.restdemo.Models.DL.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restapidemo.restdemo.Models.DL.Services.IRAddress;
import com.restapidemo.restdemo.Models.POJO.RAddress;
import com.restapidemo.restdemo.Models.Repositories.RAddressRepository;
@Service
public class RAddressServiceImpl implements IRAddress {
	@Autowired
	RAddressRepository rAddressRepository;

	@Override
	public String insertAddress(RAddress A) {
		Optional<RAddress> rAddress = rAddressRepository.findById(A.getAddressid());

		if (rAddress.isEmpty()) {
			rAddressRepository.save(A);
			return "Address added";
		} else {
			return "Address already present";
		}
	}

	@Override
	public String updateAddress(RAddress newAddr, int addressid) {
		Optional<RAddress> rAddress = rAddressRepository.findById(newAddr.getAddressid());

		if (rAddress.isPresent()) {
			rAddressRepository.save(newAddr);
			return "Address updated";
		} else {
			return "Address not present";
		}
	}

	@Override
	public List<RAddress> getAddresses() {
		return rAddressRepository.findAll();
	}

	@Override
	public Optional<RAddress> getAddressById(int addressid) {
		return rAddressRepository.findById(addressid);
	}

	@Override
	public String deleteAddress(int addressid) {
		Optional<RAddress> rAddress = rAddressRepository.findById(addressid);

		if (rAddress.isPresent()) {
			rAddressRepository.deleteById(addressid);;
			return "Address Deleted";
		} else {
			return "Address not  present";
		}

	}

}
