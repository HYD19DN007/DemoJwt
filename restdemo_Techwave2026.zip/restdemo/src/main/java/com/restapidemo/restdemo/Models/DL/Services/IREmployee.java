package com.restapidemo.restdemo.Models.DL.Services;

import java.util.List;
import java.util.Optional;

import com.restapidemo.restdemo.Models.POJO.REmployee;
import com.restapidemo.restdemo.dto.EmpdeptaddrDto;
import com.restapidemo.restdemo.dto.Employeedto;

public interface IREmployee {
	String AddEmployee(Employeedto E);

	String UpdateEmployee(REmployee newemp, int empno);

	String deleteEmployee(int empno);

	List<REmployee> getall();

	Optional<REmployee> getById(int empno);
	List<REmployee>getByname(String S);
	List<REmployee>getByGen(String gender);
	List<EmpdeptaddrDto>getalldetails();
	
}
