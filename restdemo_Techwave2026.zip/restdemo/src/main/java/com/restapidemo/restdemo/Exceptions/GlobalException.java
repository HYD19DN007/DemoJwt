package com.restapidemo.restdemo.Exceptions;

import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
@ControllerAdvice
public class GlobalException {
	@ExceptionHandler(NoSuchElementException.class)
	public ResponseEntity<String> handleException(NoSuchElementException E)
	{
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(E.getMessage());
	}
	
	@ExceptionHandler(UserDefinedException.class)
	public ResponseEntity<String> handleException2(UserDefinedException E)
	{
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(E.getMessage());
	}
	
}
