package com.restapidemo.restdemo.Models.DL.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restapidemo.restdemo.Models.DL.Services.IREmployee;
import com.restapidemo.restdemo.Models.POJO.RAddress;
import com.restapidemo.restdemo.Models.POJO.RDept;
import com.restapidemo.restdemo.Models.POJO.REmployee;
import com.restapidemo.restdemo.Models.Repositories.DeptRepository;
import com.restapidemo.restdemo.Models.Repositories.RAddressRepository;
import com.restapidemo.restdemo.Models.Repositories.REmployeeRepository;
import com.restapidemo.restdemo.dto.EmpdeptaddrDto;
import com.restapidemo.restdemo.dto.Employeedto;

@Service
public class REmployeeServiceImpl implements IREmployee {
	@Autowired
	RAddressRepository rAddressRepository;
	@Autowired
	REmployeeRepository rEmployeeRepository;
	@Autowired
	DeptRepository deptRepository;
	@Override
	public String AddEmployee(Employeedto E) {
		Optional<RAddress> address =rAddressRepository.findById(E.getAddid());//100
		Optional<RDept>dept=deptRepository.findById(E.getDeptno());
		if(address.isPresent() && dept.isPresent()) 
		{
			Optional<REmployee>oldemp=rEmployeeRepository.findById(E.getEmpno());
			if(oldemp.isEmpty())
					{
					REmployee emp=new REmployee();
					emp.setEmpno(E.getEmpno());
					emp.setEname(E.getEname());
					emp.setGender(E.getGender());
					emp.setDept(dept.get());
					emp.setAddress(address.get());
					rEmployeeRepository.save(emp);
					return "Employee Saved";
		
					
					}
					else
					{
						return "Employee Exists";
					}
		}
		else
			return "Address/Dept not found";
		}

	@Override
	public String UpdateEmployee(REmployee newemp, int empno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(int empno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<REmployee> getall() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<REmployee> getById(int empno) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public List<REmployee> getByname(String S) {
		// TODO Auto-generated method stub
return rEmployeeRepository.findByEnameLike(S);
	}

	@Override
	public List<REmployee> getByGen(String gender) {
		// TODO Auto-generated method stub
return rEmployeeRepository.findByGender(gender);
	}

	@Override
	public List<EmpdeptaddrDto> getalldetails() {
		// TODO Auto-generated method stub
		return rEmployeeRepository.getalldetails();
	}

}
