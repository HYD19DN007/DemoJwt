package com.restapidemo.restdemo.Controllers;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restapidemo.restdemo.Exceptions.UserDefinedException;
import com.restapidemo.restdemo.Models.BL.CustomerBL;
import com.restapidemo.restdemo.Models.POJO.Customer;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	CustomerBL customerBL;

	@PostMapping("/add")
	public ResponseEntity<String> AddCustomer(@RequestBody Customer C) {
		try {
			String S = customerBL.addCustomer(C);
			return new ResponseEntity<>(S, HttpStatus.OK);
		} catch (DataIntegrityViolationException E) {
			if (E.getMessage().contains("CHK_DIFF"))
				return new ResponseEntity<>("Date of registration must be > date of birth", HttpStatus.BAD_REQUEST);
			else if (E.getMessage().contains("CHKGENDER"))
				return new ResponseEntity<>("Gender is invalid", HttpStatus.BAD_REQUEST);
			else if (E.getMessage().contains("CHKDOR"))
				return new ResponseEntity<>("Date of registration must be > 10-Oct-2025", HttpStatus.BAD_GATEWAY);
			else if (E.getMessage().contains("UNQEMAIL"))
				return new ResponseEntity<>("Email invalid", HttpStatus.BAD_REQUEST);
			else if (E.getMessage().contains("UNQPANCARD"))
				return new ResponseEntity<>("Pancard invalid", HttpStatus.BAD_REQUEST);
			else
				return new ResponseEntity<>("Error occured", HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/getall")
	public ResponseEntity<?> getall() {
		List<Customer> list = customerBL.getAll();
		if (list.size() != 0)
			// return new ResponseEntity<>(list,HttpStatus.Ok);
			// return ResponseEntity.ok(list);
			return ResponseEntity.status(HttpStatus.OK).body(list);
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No Customer found");
	}

	@GetMapping("/getbyId/{id}")
	public ResponseEntity<?>  getbyId(@PathVariable("id") Long id) {

		try {
			return new ResponseEntity<Customer>(customerBL.getbyId(id),HttpStatus.OK);
		} catch (NoSuchElementException E) {
			return new ResponseEntity<String>("No element found with this id",HttpStatus.NOT_FOUND);
		}

	}
	
	@GetMapping("/fetchbyId/{id}")
	public Customer  fetchbyId(@PathVariable("id") Long id) {

		return customerBL.getbyId(id);

	}
	@ExceptionHandler(UserDefinedException.class)
	public ResponseEntity<String> handleException2(UserDefinedException E)
	{
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(E.getMessage());
	}
	
	
}
