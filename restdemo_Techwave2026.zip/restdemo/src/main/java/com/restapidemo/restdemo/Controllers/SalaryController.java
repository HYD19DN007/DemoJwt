package com.restapidemo.restdemo.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restapidemo.restdemo.Models.BL.RSalaryBL;
import com.restapidemo.restdemo.Models.POJO.RSalary;
import com.restapidemo.restdemo.dto.EmpDeptSalDto;
import com.restapidemo.restdemo.dto.EmpSalDeptDto;
import com.restapidemo.restdemo.dto.Salarydto;

@RestController
@RequestMapping("/salary")
public class SalaryController {
	@Autowired
	RSalaryBL rSalaryBL;

	@PostMapping("/add")
	public String AddSalary(@RequestBody Salarydto R) {
		System.out.println(R);
		return rSalaryBL.addSalary(R);
	}
	@GetMapping("/addall")
	public List<RSalary> AddAll() {
		return rSalaryBL.getAllSalaries();
	}
	
	@GetMapping("/getall/{b}/{c}")
	public List<EmpDeptSalDto> getall(@PathVariable int b,@PathVariable String c) {
		return rSalaryBL.getall(b,c);
	}
}
