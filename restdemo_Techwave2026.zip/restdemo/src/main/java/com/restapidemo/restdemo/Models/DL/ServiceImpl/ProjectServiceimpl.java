package com.restapidemo.restdemo.Models.DL.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restapidemo.restdemo.Models.DL.Services.IProject;
import com.restapidemo.restdemo.Models.POJO.Project;
import com.restapidemo.restdemo.Models.Repositories.ProjectRepository;
@Service
public class ProjectServiceimpl implements IProject {

	@Autowired
	ProjectRepository projectRepository;
	
	@Override
	public String insertProject(Project P) {//Project P=new Project(1,'BMS',Localdate.parse('2025-09-02'),25,"Phani")
		Optional<Project>project  
			=projectRepository.findById(P.getProjectid());
		if(project.isPresent())
			return "Project with id already exits";
		else
		{
			projectRepository.save(P);
			return "Project Details added";
		}
		
	}

	@Override
	public List<Project> getallprojects() {
		// TODO Auto-generated method stub
		return projectRepository.findAll();
	}

	@Override
	public String update(Project newp, int projectid) {
	 Project old=	projectRepository.findById(projectid).get();
	
	 if(old==null)
	 {
		 return "No project found with this projectid "+ projectid;
	 }
	 else
	 {
		 //projectRepository.save(newp);
		 return "Project details updated succesfully";
	 }
	}

	@Override
	public String Delete(int projectid) {
		Optional<Project>P=projectRepository.findById(projectid);
		if(P.isEmpty())
			return " No project found with projectId " +projectid;
		else
		{
			projectRepository.deleteById(projectid);
			return "deleted Successfully";
			
		}
			
			
	
	
	}
}
//
//1   HMS  2026-08-01,40,CHANDU