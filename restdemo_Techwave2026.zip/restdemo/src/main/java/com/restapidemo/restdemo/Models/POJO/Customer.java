package com.restapidemo.restdemo.Models.POJO;

import java.time.LocalDate;

import org.hibernate.annotations.Check;

import jakarta.persistence.CheckConstraint;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table
(name="customer",
check= {
		@CheckConstraint(name="CHK_DIFF",constraint = "dateofbirth<dateofregistration"),
		@CheckConstraint(name="CHKGENDER",constraint = "gender in('Male','Female')"),
		@CheckConstraint(name="CHKDOR",constraint = "dateofregistration>='10-Oct-2025'")
	},
uniqueConstraints= {
		@UniqueConstraint(name="UNQEMAIL",columnNames = "email"),
		@UniqueConstraint(name="UNQPANCARD",columnNames = "pancard")
		
		
}		
)
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long customerid;
	@NotBlank(message = "Name cannot be blank")
	@Column(length = 20)  //JPA annotation
	private String name;
	@Column(length = 6)
	private String gender;
	@Column(length = 20)
	private String email;
	@Column(length = 10)
	@Pattern(regexp ="^[A-Z]{5}[0-9]{4}[A-Z]$")//Jpa Spring boot
	private String pancard;
	private LocalDate dateofregistration;
	private LocalDate dateofbirth;
}
