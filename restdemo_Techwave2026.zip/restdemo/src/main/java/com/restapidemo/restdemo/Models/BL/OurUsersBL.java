package com.restapidemo.restdemo.Models.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.restapidemo.restdemo.Models.DL.ServiceImpl.OurUserServiceImpl;
import com.restapidemo.restdemo.Models.POJO.OurUsers;
import com.restapidemo.restdemo.dto.UserRequestDto;

public class OurUsersBL {
	@Autowired
	OurUserServiceImpl ourUserServiceImpl;

	public String CreateUser(UserRequestDto U) {
		return ourUserServiceImpl.CreateUser(U);
	}

	public List<OurUsers> getall() {
		// TODO Auto-generated method stub
		return ourUserServiceImpl.getall();
	}
	public String ValidateUser(UserRequestDto userdto) {
	return ourUserServiceImpl.ValidateUser(userdto);
	}

}
