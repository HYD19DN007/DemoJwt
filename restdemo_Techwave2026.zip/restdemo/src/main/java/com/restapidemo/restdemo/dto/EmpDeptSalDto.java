package com.restapidemo.restdemo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data

public class EmpDeptSalDto {
	private String ename;
	private String dname;
	private String city;
	private int basic;
}
