package com.restapidemo.restdemo.Models.DL.ServiceImpl;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restapidemo.restdemo.Models.DL.Services.IEmpdata;
import com.restapidemo.restdemo.Models.POJO.Empdata;
import com.restapidemo.restdemo.Models.Repositories.EmpdataRepository;
import com.restapidemo.restdemo.dto.EmpDeptwithNQDto;
import com.restapidemo.restdemo.dto.Sumsal;
@Service
public class EmpdataServiceImpl implements IEmpdata {

	@Autowired
	EmpdataRepository empdataRepository;
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return (int)empdataRepository.count();
	}
	@Override
	public int getCountBydeptno(int deptno) {
		// TODO Auto-generated method stub
		return (int)empdataRepository.countByDeptno(deptno);
	}
	@Override
	public int getCountBySalary(int S) {
		// TODO Auto-generated method stub
		return (int)empdataRepository.countBySalGreaterThan(S);
	}
	@Override
	public List<Sumsal> getSumofSalaries() {
		// TODO Auto-generated method stub
		return empdataRepository.SumofSalaries();
	}
	@Override
	public List<Empdata> getbyJob(String J) {
		// TODO Auto-generated method stub
		return empdataRepository.getbyJob(J);
	}
	@Override
	public List<EmpDeptwithNQDto> getwithDeptname() {
		// TODO Auto-generated method stub
		return empdataRepository.getwithdname();
	}
	@Override
	public Empdata getById(int id) {
		// TODO Auto-generated method stub
		return empdataRepository.findById(id).orElseThrow(()->new NoSuchElementException("Could not find the id "+id));
	}
	

}
