package com.restapidemo.restdemo.Models.POJO;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class RSalary {

	@Id
	private Integer empno;
	@OneToOne
	@MapsId
	@JoinColumn(name = "empno")
	private REmployee employee;

	private Integer basic;
}
//empno,ename,dname,hnocity,pincode
