package com.restapidemo.restdemo.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restapidemo.restdemo.Models.BL.OurUsersBL;
import com.restapidemo.restdemo.Models.POJO.OurUsers;
import com.restapidemo.restdemo.dto.UserRequestDto;

@RestController
@RequestMapping("/auth")
public class OurUserController {

	@Autowired
	OurUsersBL ourUsersBL;

	@PostMapping("create")
	public String Create(@RequestBody UserRequestDto user) {
		return ourUsersBL.CreateUser(user);
	}
	@GetMapping("getall")
	public List<OurUsers> getAll() {
		return ourUsersBL.getall();
	}
	@GetMapping("validate")
	public String validate(@RequestBody UserRequestDto userdto) {
		return ourUsersBL.ValidateUser(userdto);
	}
}
