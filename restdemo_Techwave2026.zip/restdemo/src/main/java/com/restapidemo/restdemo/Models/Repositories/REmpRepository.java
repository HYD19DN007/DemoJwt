package com.restapidemo.restdemo.Models.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.restapidemo.restdemo.Models.POJO.REmp;
@Repository
public interface REmpRepository extends JpaRepository<REmp, Integer>{

}
