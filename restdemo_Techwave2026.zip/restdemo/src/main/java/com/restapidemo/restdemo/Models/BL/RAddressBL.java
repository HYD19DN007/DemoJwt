package com.restapidemo.restdemo.Models.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.restapidemo.restdemo.Models.DL.ServiceImpl.RAddressServiceImpl;
import com.restapidemo.restdemo.Models.POJO.RAddress;

public class RAddressBL {
	@Autowired
	RAddressServiceImpl rAddressServiceImpl;

	public String insertAddress(RAddress A) {
		return rAddressServiceImpl.insertAddress(A);
	}

	public String updateAddress(RAddress A, int addressid) {
		return rAddressServiceImpl.updateAddress(A, addressid);
	}

	public List<RAddress> getAddresses() {
		return rAddressServiceImpl.getAddresses();
	}

	public RAddress getAddressById(int addressid) {
		return rAddressServiceImpl.getAddressById(addressid).get();
	}

	public String deleteAddress(int addressid) {
		return rAddressServiceImpl.deleteAddress(addressid);
	}

}
