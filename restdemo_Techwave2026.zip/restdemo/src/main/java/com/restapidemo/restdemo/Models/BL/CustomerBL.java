package com.restapidemo.restdemo.Models.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.restapidemo.restdemo.Models.DL.ServiceImpl.CustomerServiceImpl;
import com.restapidemo.restdemo.Models.POJO.Customer;

public class CustomerBL {
	@Autowired
	CustomerServiceImpl customerServiceImpl;
	public String addCustomer(Customer c) {
		// TODO Auto-generated method stub
		customerServiceImpl.addCustomer(c);
		return "1 customer added";
	}

	public List<Customer> getAll() {
		// TODO Auto-generated method stub
		return customerServiceImpl.getAll();
	}

	public Customer getbyId(long custid) {
		// TODO Auto-generated method stub
		 return customerServiceImpl.getbyId(custid);
		 
	}

}
