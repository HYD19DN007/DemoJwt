package com.restapidemo.restdemo.Models.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.restapidemo.restdemo.Models.POJO.REmployee;
import com.restapidemo.restdemo.Models.POJO.RSalary;
import com.restapidemo.restdemo.dto.EmpDeptSalDto;
import com.restapidemo.restdemo.dto.EmpSalDeptDto;
@Repository
public interface RSalaryRepository extends JpaRepository<RSalary, Integer>{

//	@Query("""
//			select new com.restapidemo.restdemo.dto.EmpDeptSalDto
//			(
//			e.ename,e.dept.dname,e.address.city,s.basic
//			) from REmployee e inner join RSalary s on e.empno=s.empno
//			
//			""")
//	@Query("""
//			select new com.restapidemo.restdemo.dto.EmpDeptSalDto
//			(
//			S.employee.ename,S.employee.dept.dname,S.employee.address.city,S.basic
//				
//						) from RSalary S where S.basic>=:b and S.employee.address.city like :c
//			
//			""")
	//List<EmpDeptSalDto>getall(@Param("b") int b,@Param("c") String c);

	@Query("""
	select new com.restapidemo.restdemo.dto.EmpDeptSalDto
	(
	S.employee.ename,S.employee.dept.dname,S.employee.address.city,S.basic
		
				) from RSalary S where S.basic>=?1 and S.employee.address.city like ?2
	
	""")
	List<EmpDeptSalDto>getall(int b, String c);

	
	

}
