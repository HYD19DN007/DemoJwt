package com.restapidemo.restdemo.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class EmpDeptDto {
	private int empno;
	private int deptno;
	private LocalDate startdate;
	private LocalDate enddate;
}
