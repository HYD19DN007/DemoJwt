package com.restapidemo.restdemo.Models.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.restapidemo.restdemo.Models.DL.ServiceImpl.EmpDeptServiceImpl;
import com.restapidemo.restdemo.Models.POJO.Emp_Dept;
import com.restapidemo.restdemo.dto.EmpDeptDto;
import com.restapidemo.restdemo.dto.EmpDeptdetailsdto;

public class EmpDeptBL {

	@Autowired
	EmpDeptServiceImpl empDeptServiceImpl;
	public String addempdept(EmpDeptDto E)
	{
		return empDeptServiceImpl.adddeptallocation(E);
	}
public List<Emp_Dept> getall() {
		
		return empDeptServiceImpl.getall();
	}
public List<EmpDeptDto> getdetails() {
	// TODO Auto-generated method stub
	return empDeptServiceImpl.getdetails();
}
public List<EmpDeptdetailsdto> getalldetails() {
	// TODO Auto-generated method stub
	return empDeptServiceImpl.getalldetails();
}

}
