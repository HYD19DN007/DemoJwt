package com.restapidemo.restdemo.Models.DL.Services;

import java.util.List;

import com.restapidemo.restdemo.Models.POJO.Project;

public interface IProject {
	String insertProject(Project P);

	List<Project> getallprojects();
	String update(Project P,int projectid);
	String Delete(int projectid);
}
