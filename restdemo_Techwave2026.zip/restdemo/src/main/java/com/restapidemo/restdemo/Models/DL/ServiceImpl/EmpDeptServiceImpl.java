package com.restapidemo.restdemo.Models.DL.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restapidemo.restdemo.Models.DL.Services.IEmpDept;
import com.restapidemo.restdemo.Models.POJO.EmpDeptComposite;
import com.restapidemo.restdemo.Models.POJO.Emp_Dept;
import com.restapidemo.restdemo.Models.POJO.RDept;
import com.restapidemo.restdemo.Models.POJO.REmp;
import com.restapidemo.restdemo.Models.Repositories.DeptRepository;
import com.restapidemo.restdemo.Models.Repositories.EmpDeptRepository;
import com.restapidemo.restdemo.Models.Repositories.REmpRepository;
import com.restapidemo.restdemo.dto.EmpDeptDto;
import com.restapidemo.restdemo.dto.EmpDeptdetailsdto;
@Service
public class EmpDeptServiceImpl implements IEmpDept{
	@Autowired
	DeptRepository deptRepository;
	@Autowired
	REmpRepository rEmpRepository;
	@Autowired
	EmpDeptRepository empDeptRepository;
	
	@Override
	public String adddeptallocation(EmpDeptDto E) {
	System.out.println(E.getStartdate());
	System.out.println(E.getEnddate());
	Optional<RDept>dept=deptRepository.findById(E.getDeptno());
	Optional<REmp>emp=rEmpRepository.findById(E.getEmpno());
	if(dept.isPresent() && emp.isPresent())
	{
		Emp_Dept ED=new Emp_Dept();
//		EmpDeptComposite EC=new EmpDeptComposite();
//		EC.setDept(dept.get());
//		EC.setEmp(emp.get());
//		EC.setStartDate(E.getStartdate());
//		ED.setEnddate(E.getEnddate());
//		ED.setEmpdept(EC);
		ED.getEmpdept().setDept(dept.get());
		ED.getEmpdept().setEmp(emp.get());
		ED.getEmpdept().setStartdate(E.getStartdate());
		ED.setEnddate(E.getEnddate());
		empDeptRepository.save(ED);
		return "Data saved";
		
	}
	else
		return "Dept/Emp does not exist";
	
	}

	@Override
	public List<Emp_Dept> getall() {
		
		return empDeptRepository.findAll();
	}

	@Override
	public List<EmpDeptDto> getdetails() {
		// TODO Auto-generated method stub
		return empDeptRepository.getdetails();
	}

	@Override
	public List<EmpDeptdetailsdto> getalldetails() {
		// TODO Auto-generated method stub
		return empDeptRepository.getalldetails();
	}

	
	
}
