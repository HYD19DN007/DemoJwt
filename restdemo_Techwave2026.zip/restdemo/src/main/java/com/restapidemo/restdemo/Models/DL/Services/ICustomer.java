package com.restapidemo.restdemo.Models.DL.Services;

import java.util.List;

import com.restapidemo.restdemo.Models.POJO.Customer;

public interface ICustomer {
	String addCustomer(Customer c);

	List<Customer> getAll();

	Customer getbyId(long custid);
	Customer fetchbyId(long custid);
}
