package com.restapidemo.restdemo.Models.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.restapidemo.restdemo.Models.POJO.Empdata;
import com.restapidemo.restdemo.dto.EmpDeptwithNQDto;
import com.restapidemo.restdemo.dto.Sumsal;
@Repository
public interface EmpdataRepository extends JpaRepository<Empdata, Integer>{
   //Derived Queries
	long countByDeptno(int deptno);
	long countBySalGreaterThan(int S);
	@Query("""
			select new com.restapidemo.restdemo.dto.Sumsal(e.deptno,sum(e.sal)) from Empdata e group by e.deptno 
			""")
	List<Sumsal>SumofSalaries();
	List<Empdata> getbyJob(String J);
	List<EmpDeptwithNQDto>getwithdname();
	
}
