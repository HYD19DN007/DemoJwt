package com.restapidemo.restdemo.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restapidemo.restdemo.Models.BL.ProjectBL;
import com.restapidemo.restdemo.Models.BL.RAddressBL;
import com.restapidemo.restdemo.Models.POJO.Project;
import com.restapidemo.restdemo.Models.POJO.RAddress;

@RestController
@RequestMapping("/Address")
public class AddressController {
	@Autowired
	RAddressBL rAddressBL;
	
	@PostMapping("/addaddress")
	public String addaddress(@RequestBody RAddress A)
	{
		return rAddressBL.insertAddress(A);
	}
	@GetMapping("/getall")
	public List<RAddress> getAll()
	{
		return rAddressBL.getAddresses();
	}
	
	@PutMapping("/updateAddress/{aid}")
	public String update(@RequestBody RAddress A, @PathVariable("aid") int aid)
	{
		if(A.getAddressid()==aid)
			return rAddressBL.updateAddress(A, aid);
		else
			return "AddressId not valid";
	}
	
	@DeleteMapping("/delete/{aid}")
	public String Delete(@PathVariable("aid") int aid)
	{
		return rAddressBL.deleteAddress(aid);
		
			
	}

}
