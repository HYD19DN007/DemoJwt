package com.restapidemo.restdemo.Models.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.restapidemo.restdemo.Models.DL.ServiceImpl.ProjectServiceimpl;
import com.restapidemo.restdemo.Models.POJO.Project;

public class ProjectBL {
@Autowired
ProjectServiceimpl projectServiceimpl;
public String insertProject(Project P)
{
	return projectServiceimpl.insertProject(P);
	
}
public List<Project> getallprojects()
{
	return projectServiceimpl.getallprojects();
}

public String UpdateProject(Project newp,int projectid)
{
	String S=projectServiceimpl.update(newp, projectid);
	return S;
}

public String DeleteProject(int projectid)
{
	String S=projectServiceimpl.Delete(projectid);
	return S;
}

}
