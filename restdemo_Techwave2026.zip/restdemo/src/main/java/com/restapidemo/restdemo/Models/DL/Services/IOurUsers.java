package com.restapidemo.restdemo.Models.DL.Services;

import java.util.List;

import com.restapidemo.restdemo.Models.POJO.OurUsers;
import com.restapidemo.restdemo.dto.UserRequestDto;

public interface IOurUsers {
String CreateUser(UserRequestDto U);
List<OurUsers> getall();
String ValidateUser(UserRequestDto userdto);
}
