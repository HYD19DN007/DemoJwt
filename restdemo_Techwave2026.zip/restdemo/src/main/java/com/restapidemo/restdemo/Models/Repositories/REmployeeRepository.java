package com.restapidemo.restdemo.Models.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.restapidemo.restdemo.Models.POJO.REmployee;
import com.restapidemo.restdemo.dto.EmpdeptaddrDto;

@Repository
public interface REmployeeRepository extends JpaRepository<REmployee, Integer> {
	
	//Derived Queries
	List<REmployee> findByEnameLike(String ename);
	List<REmployee>findByGender(String gender);

	@Query("""
			select new com.restapidemo.restdemo.dto.EmpdeptaddrDto(
			E.empno,E.ename,E.gender,
			E.dept.dname,
			E.address.hno,
			E.address.city,
			E.address.picode)
			 from REmployee E
			""")
	public List<EmpdeptaddrDto>getalldetails();
	
	
}
