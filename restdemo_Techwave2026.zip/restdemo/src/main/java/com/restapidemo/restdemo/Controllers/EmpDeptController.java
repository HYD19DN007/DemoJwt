package com.restapidemo.restdemo.Controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restapidemo.restdemo.Models.BL.EmpDeptBL;
import com.restapidemo.restdemo.Models.POJO.Emp_Dept;
import com.restapidemo.restdemo.dto.EmpDeptDto;
import com.restapidemo.restdemo.dto.EmpDeptdetailsdto;

@RestController
@RequestMapping("/EmpDept")
public class EmpDeptController {
	@Autowired
	EmpDeptBL empDeptBL;

	@PostMapping("/add")
	public String add(@RequestBody EmpDeptDto E) {
		return empDeptBL.addempdept(E);
	}

	@GetMapping("/getall")
	public List<Emp_Dept> getall() {
		return empDeptBL.getall();

	}
	
	
	@GetMapping("/getdetails")
	public List<EmpDeptDto> getdetails() {
		 return empDeptBL.getdetails();
				
		}
	@GetMapping("/getalldetails")
	public List<EmpDeptdetailsdto> getalldetails() {
		 return empDeptBL.getalldetails();
				
		}

	}


