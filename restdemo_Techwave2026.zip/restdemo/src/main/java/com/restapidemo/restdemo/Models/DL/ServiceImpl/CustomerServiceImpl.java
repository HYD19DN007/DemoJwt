package com.restapidemo.restdemo.Models.DL.ServiceImpl;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restapidemo.restdemo.Exceptions.UserDefinedException;
import com.restapidemo.restdemo.Models.DL.Services.ICustomer;
import com.restapidemo.restdemo.Models.POJO.Customer;
import com.restapidemo.restdemo.Models.Repositories.CustomerRepository;

@Service
public class CustomerServiceImpl implements ICustomer {

	@Autowired
	CustomerRepository customerRepository;
	@Override
	public String addCustomer(Customer c) {
		// TODO Auto-generated method stub
		customerRepository.save(c);
		return "1 customer added";
	}

	@Override
	public List<Customer> getAll() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	@Override
	public Customer getbyId(long custid) {
		 return customerRepository.findById(custid).get();
		 
	}

	@Override
	public Customer fetchbyId(long custid) {
		// TODO Auto-generated method stub
	//	return customerRepository.findById(custid).orElseThrow(()->new NoSuchElementException("No Customer found"));
		Optional<Customer>C= customerRepository.findById(custid);
		if(C.isPresent())
				return C.get();
		else
			throw new NoSuchElementException("No Element found");
	}

}
