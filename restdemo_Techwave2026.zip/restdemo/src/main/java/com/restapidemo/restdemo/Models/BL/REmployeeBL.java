package com.restapidemo.restdemo.Models.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.restapidemo.restdemo.Models.DL.ServiceImpl.REmployeeServiceImpl;
import com.restapidemo.restdemo.Models.POJO.REmployee;
import com.restapidemo.restdemo.dto.EmpdeptaddrDto;
import com.restapidemo.restdemo.dto.Employeedto;

public class REmployeeBL {
	@Autowired
	REmployeeServiceImpl rEmployeeServiceImpl;

	public String addEmployee(Employeedto E) {
		return rEmployeeServiceImpl.AddEmployee(E);
	}
	public List<REmployee> getByname(String S) {
		// TODO Auto-generated method stub
 return rEmployeeServiceImpl.getByname(S);
	}
	public List<REmployee> getByGen(String gender) {
		// TODO Auto-generated method stub
return rEmployeeServiceImpl.getByGen(gender);
	}
	public List<EmpdeptaddrDto> getalldetails() {
		// TODO Auto-generated method stub
		return rEmployeeServiceImpl.getalldetails();
	}

}
