package com.restapidemo.restdemo.Models.DL.Services;

import java.util.List;
import java.util.Optional;

import com.restapidemo.restdemo.Models.POJO.RAddress;

public interface IRAddress {
	
	String insertAddress(RAddress A);

	String updateAddress(RAddress A, int addressid);

	List<RAddress> getAddresses();

	Optional<RAddress> getAddressById(int addressid);

	String deleteAddress(int addressid);

}
