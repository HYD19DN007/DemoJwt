package com.restapidemo.restdemo.Models.POJO;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class REmployee {
	@Id
	private Integer empno;//findByEname
	@Column(length = 20)
	private String ename;
	@Column(length = 6)
	private String gender;
	@Transient
	private int addid;//100
	@OneToOne
	@JoinColumn(name = "addrid")
	private RAddress address;//End user will not enter
//	private int deptno;
	@ManyToOne
	@JoinColumn(name="deptno")
	private RDept dept;
	

}
